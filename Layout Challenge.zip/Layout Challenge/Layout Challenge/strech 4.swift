//
//  strech 4.swift
//  Layout Challenge
//
//  Created by Link, Ty - Student on 8/29/24.
//
//
//import SwiftUI
//
//struct strech_4: View {
//    var body: some View {
//            
//            ZStack {
//                PriceingView4(title: "Basic", price: "$9", textColor: .white, icon: "staroflife.fill", bgColor: .purple)
//                    .frame(width: 360)
//                    .offset(x: 0, y: 480)
//                
//                ZStack {
//                    PriceingView4(title: "Pro", price: "$19", textColor: .white, icon: "sun.min", bgColor: (Color(red: 255/255, green: 183/255, blue: 37/255))
//                        .frame(width: 330)
//                        .offset(x: 0, y: 280)
//
//
//                }
//                
//            }
//           
//            .padding(11)
//            ZStack {
//                PriceingView4(title: "Team", price: "$299", textColor: .white, icon: "wand.and.rays", bgColor: Color(red: 62/255, green: 63/255, blue: 70/255))
//                    .frame(width: 300)
//                    .offset(x: 0, y: -156)
//                
//
//            }
//                Spacer()
//            }
//      
//        }
//    
//
//
//#Preview {
//    strech_4()
//}
//
//struct ExtractedView4: View {
//    
//    var body: some View {
//        HStack {
//            VStack(alignment: .leading, spacing: 2) {
//                Text("Choose")
//                    .font(.system(.largeTitle, design: .rounded))
//                    .fontWeight(.black)
//                Text("Your Plan")
//                    .font(.system(.largeTitle, design: .rounded))
//                    .fontWeight(.black)
//            }
//            Spacer()
//        }
//        .padding()
//    }
//}
//
//struct PriceingView4: View {
//    
//    var title: String
//    var price: String
//    var textColor: Color
//    var icon: String?
//    
//    var bgColor: Color
//    
//   
//   
//    
//    var body: some View {
//            VStack {
//                
//                if let icon = icon {
//                    Image(systemName: icon)
//                        .font(.largeTitle)
//                        .foregroundStyle(textColor)
//                }
//                Text(title)
//                    .font(.system(.title, design: .rounded))
//                    .fontWeight(.black)
//                    .foregroundStyle(textColor)
//                Text(price)
//                    .font(.system(size: 40, weight: .heavy, design: .rounded))
//                    .foregroundStyle(textColor)
//                Text("per month")
//                    .font(.headline)
//                    .foregroundStyle(textColor)
//            }
//            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 100)
//            .padding(40)
//            .background(bgColor)
//            .cornerRadius(10)
//        
//           
//            
//        }
//}
//
//#Preview {
//    strech_4()
//}
