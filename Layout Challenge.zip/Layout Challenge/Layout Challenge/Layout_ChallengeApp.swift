//
//  Layout_ChallengeApp.swift
//  Layout Challenge
//
//  Created by Link, Ty - Student on 8/28/24.
//

import SwiftUI

@main
struct Layout_ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
