//
//  strech 1.swift
//  Layout Challenge
//
//  Created by Link, Ty - Student on 8/28/24.
//

import SwiftUI

struct strech_1: View {
    var body: some View {
                VStack{
                    ExtractedView1()
                    
                    HStack(spacing: 15) {
                        PriceingView1(title: "Basic", price: "$9", textColor: .white, bgColor: .purple)
                        ZStack {
                            PriceingView1(title: "Pro", price: "$19", textColor: .black, bgColor: Color(red: 240/255, green: 240/255, blue: 240/255))
                            
                            Text("Best for designer")
                                .font(.system(.caption, design: .rounded))
                                .fontWeight(.bold)
                                .foregroundStyle(.white)
                                .padding(5)
                                .background(Color(red: 255/255, green: 183/255, blue: 37/255))
                                .offset(x: 0, y: 87)
                        }
                        //.padding(.horizontal)
                    }
                   // .padding(.horizontal)
                    .padding(11)
                    ZStack {
                        PriceingView1(title: "Team", price: "$299", textColor: .white, bgColor: Color(red: 62/255, green: 63/255, blue: 70/255), icon: "wand.and.rays")
                        
                        Text("Perfet for teams with 20 members")
                            .font(.system(.caption, design: .rounded))
                            .fontWeight(.bold)
                            .foregroundStyle(.white)
                            .padding(5)
                            .background(Color(red: 255/255, green: 183/255, blue: 37/255))
                            .offset(x:0, y: 110)
                        
                            .padding(100)
                    }
                    Image("purrple")
                        .resizable()
                        
                    }
                .padding(.horizontal)
                }
            }


        #Preview {
            strech_1()
        }

        struct ExtractedView1: View {
            
            var body: some View {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Choose")
                            .font(.system(.largeTitle, design: .rounded))
                            .fontWeight(.black)
                        Text("Your Plan")
                            .font(.system(.largeTitle, design: .rounded))
                            .fontWeight(.black)
                    }
                    Spacer()
                }
                .padding()
            }
        }

        struct PriceingView1: View {
            
            var title: String
            var price: String
            var textColor: Color
            var bgColor: Color
            var icon: String?
            
            var body: some View {
                    VStack {
                        
                        if let icon = icon {
                            Image(systemName: icon)
                                .font(.largeTitle)
                                .foregroundStyle(textColor)
                        }
                        Text(title)
                            .font(.system(.title, design: .rounded))
                            .fontWeight(.black)
                            .foregroundStyle(textColor)
                        Text(price)
                            .font(.system(size: 40, weight: .heavy, design: .rounded))
                            .foregroundStyle(textColor)
                        Text("per month")
                            .font(.headline)
                            .foregroundStyle(textColor)
                    }
                    .frame(minWidth: 0, maxWidth: .infinity, minHeight: 100)
                    .padding(40)
                    .background(bgColor)
                    .cornerRadius(10)
                    
                }
            
        }
   

#Preview {
    strech_1()
}
